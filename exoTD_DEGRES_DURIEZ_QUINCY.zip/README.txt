Exo de TD de Maxime DEGRES, Jean-Baptiste DURIEZ et Jordane QUINCY

Le comportement des personnes est al�atoire jusqu'� ce qu'elle attrape une bo�te
Quand un personne prend une bo�te, elle se dirige vers les coordonn�es destinations de la bo�te en prenant le plus court chemin (a star)

Pour g�rer le passage dans le tunnel, un syst�me de feu a �t� mis en place.
Il alterne entre rouge et vert en fonction du temps.

Si une personne est encore dans le tunnel alors que les feux doivent changer, 
alors les deux feux se mettent au rouge jusqu'� ce qu'il n'y ait plus personne dans le tunnel.

D�s qu'il n'y a plus personne les feux se remettent en fonctionnement normal.